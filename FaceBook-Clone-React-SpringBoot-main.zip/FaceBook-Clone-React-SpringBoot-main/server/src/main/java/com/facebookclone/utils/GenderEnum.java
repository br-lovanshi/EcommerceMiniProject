package com.facebookclone.utils;

public enum GenderEnum {
    MALE, FEMALE
}

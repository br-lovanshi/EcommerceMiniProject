package com.facebookclone.utils;

public enum RelationShip {
    SINGLE, RELATION_SHIP, MARRIED, DIVORCED
}

import React, { FC, memo } from 'react';
import styles from './styles.module.scss'


export const ProfilePage: FC = memo(() => {

  return (
    <div>

    </div>
  );
});
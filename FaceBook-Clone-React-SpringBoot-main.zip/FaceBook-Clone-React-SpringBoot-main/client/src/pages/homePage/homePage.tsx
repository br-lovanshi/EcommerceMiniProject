import React, { FC, memo } from 'react';
import styles from './styles.module.scss'


export const HomePage: FC = memo(() => {

  return (
    <div>

    </div>
  );
});
package com.facebookclone.utils;

public class AppConstants {
    public static Long RANDOM_TOKEN_TIME = 1800000L;
}

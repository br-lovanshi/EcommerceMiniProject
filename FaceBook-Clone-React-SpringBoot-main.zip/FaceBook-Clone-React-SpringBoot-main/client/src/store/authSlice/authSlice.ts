import { createSlice } from '@reduxjs/toolkit';


const initialState = {

}

const authSlice = createSlice({
  name: 'auth',
  initialState: initialState,
  reducers: {



  }
})


export default authSlice.reducer
export const {

} = authSlice.actions
package com.facebookclone.entity;

public class Request {
}
